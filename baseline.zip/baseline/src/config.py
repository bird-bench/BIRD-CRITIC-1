model_config = {
    "model_name": {"api_url": "YOUR_API_URL", "api_key": "YOUR_API_KEY"},
}
