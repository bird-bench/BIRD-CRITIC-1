data_path="../data/xx.jsonl"
assistant_prompt_path="../prompts/xx.jsonl"
python ../src/prompt_generator.py --data_path $data_path --prompt_path $assistant_prompt_path --prompt_type "assistant"